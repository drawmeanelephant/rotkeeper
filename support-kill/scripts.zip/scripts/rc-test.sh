#!/usr/bin/env bash
# ░▒▓█ ROTKEEPER SCRIPT █▓▒░
# Script: rc-test.sh
# Purpose: Run dry-run tests on all rc-*.sh scripts and log their results
# Version: 0.2.0
# Updated: 2025-05-27
# -----------------------------------------

set -euo pipefail

TIMESTAMP=$(date +"%Y-%m-%d_%H%M")
LOGFILE="bones/logs/rc-test-${TIMESTAMP}.log"
SCRIPTS_DIR="bones/scripts"

mkdir -p bones/logs/

echo "🧪 Rotkeeper CLI Test — $TIMESTAMP" | tee "$LOGFILE"
echo "=====================================" | tee -a "$LOGFILE"

for f in "$SCRIPTS_DIR"/rc-*.sh; do
  script_name=$(basename "$f")

  case "$script_name" in
    rc-api.sh|rc-unpack.sh|rc-test.sh)
      echo "⚠️  Skipping $script_name (known stub/self)" | tee -a "$LOGFILE"
      continue
      ;;
  esac

  echo "🔧 Testing $script_name..." | tee -a "$LOGFILE"

  case "$script_name" in
    rc-assets.sh)
      mkdir -p home/assets/ output/assets/
      echo "dummy content" > home/assets/dummy.txt
      bash "$f" --dry-run >>"$LOGFILE" 2>&1
      ;;
    rc-docs-fix.sh)
      touch bones/logs/rc-docs-fix.tmp.md
      echo "STUB this line" > bones/logs/rc-docs-fix.tmp.md
      bash "$f" --pattern "STUB" --replace "REPLACED" --dry-run >>"$LOGFILE" 2>&1
      ;;
    rc-expand.sh)
      bash "$f" --dry-run >>"$LOGFILE" 2>&1
      ;;
    rc-reseed.sh)
      bash "$f" --archive bones/archive/fake-tomb.tar.gz --dry-run >>"$LOGFILE" 2>&1 || echo "(expected fail for dummy archive)" >>"$LOGFILE"
      ;;
    rc-scan.sh|rc-verify.sh)
      touch bones/asset-manifest.yaml
      bash "$f" --manifest bones/asset-manifest.yaml --dry-run >>"$LOGFILE" 2>&1
      ;;
    *)
      bash "$f" --dry-run >>"$LOGFILE" 2>&1
      ;;
  esac

  echo "✔️ Completed $script_name" | tee -a "$LOGFILE"
  echo "" | tee -a "$LOGFILE"

  if [[ $? -eq 0 ]]; then
    echo "✅ PASS: $script_name" | tee -a "$LOGFILE"
  else
    echo "❌ FAIL: $script_name" | tee -a "$LOGFILE"
  fi

  echo "---" | tee -a "$LOGFILE"
done

echo "🧾 Test complete. See log: $LOGFILE"