#!/usr/bin/env bash
# ░▒▓█ ROTKEEPER SCRIPT █▓▒░
# Script: rc-bless.sh
# Purpose: Update the changelog based on recent Git diffs and bless the state
# Version: 0.2.0
# Updated: 2025-05-27
# -----------------------------------------
set -euo pipefail
IFS=$'\n\t'

LOG_FILE="bones/logs/rc-bless-$(date +%Y-%m-%d_%H%M).log"

log() {
    local level="$1"; shift
    printf '%s [%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$level" "$*" | tee -a "$LOG_FILE"
}

cleanup() {
    log "INFO" "Cleaning up after rc-bless.sh."
    # Add cleanup commands here
}
trap cleanup EXIT INT TERM

check_dependencies() {
    local deps=(git rsync ssh pandoc date)
    for cmd in "${deps[@]}"; do
        command -v "$cmd" >/dev/null 2>&1 || {
            log "ERROR" "$cmd required but not installed."
            exit 1
        }
    done
}

main() {
    mkdir -p "$(dirname "$LOG_FILE")"
    check_dependencies
    log "INFO" "Running rc-bless.sh."

    mkdir -p bones/logs
    CHANGELOG="bones/logs/changelog.md"
    {
        echo "## $(date '+%Y-%m-%d %H:%M') — Blessing"
        echo ''
        if git rev-parse HEAD~1 >/dev/null 2>&1; then
            git diff --name-status HEAD~1 HEAD
        else
            echo "(no prior commit to diff against)"
        fi
        echo ''
    } >> "$CHANGELOG"
    log "INFO" "Changelog updated at $CHANGELOG"

    log "INFO" "rc-bless.sh completed successfully."
}

main "$@"