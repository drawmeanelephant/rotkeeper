#!/usr/bin/env bash
# ░▒▓█ ROTKEEPER SCRIPT █▓▒░
# Script: rc-webbook.sh
# Purpose: Bundle rendered HTML output into a single markdown reference book
# Version: 0.1.9.9
# Updated: 2025-05-27
# -----------------------------------------

set -euo pipefail

OUTPUT="bones/reports/rotkeeper-webbook.md"
SOURCE_DIR="output"

mkdir -p "$(dirname "$OUTPUT")"
echo "# 🌐 Rotkeeper Rendered Output Book" > "$OUTPUT"
echo "" >> "$OUTPUT"

find "$SOURCE_DIR" -type f -name "*.html" | sort | while read -r file; do
  echo "## 🌐 ${file}" >> "$OUTPUT"
  echo '```html' >> "$OUTPUT"
  cat "$file" >> "$OUTPUT"
  echo '```' >> "$OUTPUT"
  echo "" >> "$OUTPUT"
done

echo "✅ Webbook compiled to $OUTPUT"
