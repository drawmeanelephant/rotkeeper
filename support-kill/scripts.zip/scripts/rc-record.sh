#!/usr/bin/env bash
# ░▒▓█ ROTKEEPER SCRIPT █▓▒░
# Script: rc-record.sh
# Purpose: Log the current Git state, timestamp, and basic system info
# Version: 0.2.0
# Updated: 2025-05-27
# -----------------------------------------
set -euo pipefail
IFS=$'\n\t'
LOG_FILE="bones/logs/rc-record-$(date +%Y-%m-%d_%H%M).log"
mkdir -p "$(dirname "$LOG_FILE")"

log() {
    local level="$1"; shift
    printf '%s [%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$level" "$*" | tee -a "$LOG_FILE"
}

cleanup() {
    log "INFO" "Cleaning up after rc-record.sh."
    # Add cleanup commands here
}
trap cleanup EXIT INT TERM

check_dependencies() {
    local deps=(git rsync ssh pandoc date)
    for cmd in "${deps[@]}"; do
        command -v "$cmd" >/dev/null 2>&1 || {
            log "ERROR" "$cmd required but not installed."
            exit 1
        }
    done
}

main() {
    check_dependencies
    log "INFO" "Running rc-record.sh."

    RECORD_LOG="bones/logs/record.log"
    mkdir -p "$(dirname "$RECORD_LOG")"

    {
        echo "## Record — $(date '+%Y-%m-%d %H:%M')"
        echo "Commit: $(git rev-parse HEAD 2>/dev/null || echo '(no git repo)')"
        echo "Branch: $(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo '(unknown)')"
        echo "User: $(whoami) on $(hostname)"
        echo ""
    } >> "$RECORD_LOG"

    log "INFO" "Recorded current state to $RECORD_LOG"
    log "INFO" "rc-record.sh completed successfully."
}

main "$@"
