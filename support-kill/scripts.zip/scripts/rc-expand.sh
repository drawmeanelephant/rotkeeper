#!/usr/bin/env bash
# ░▒▓█ ROTKEEPER SCRIPT █▓▒░
# Script: rc-expand.sh
# Purpose: Generate markdown, config, and skeleton files from a BOM definition
# Version: 0.1.9.9
# Updated: 2025-05-27
# -----------------------------------------
set -euo pipefail
IFS=$'\n\t'

LOGDIR="bones/logs"
mkdir -p "$LOGDIR"
LOG_FILE="$LOGDIR/rc-expand.log"

log() {
    local level="$1"; shift
    printf '%s [%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$level" "$*" | tee -a "$LOG_FILE"
}

cleanup() {
    log "INFO" "Cleaning up after rc-expand.sh."
    # Add cleanup commands here
}
trap cleanup EXIT INT TERM

check_dependencies() {
    local deps=(git rsync ssh pandoc date)
    for cmd in "${deps[@]}"; do
        command -v "$cmd" >/dev/null 2>&1 || {
            log "ERROR" "$cmd required but not installed."
            exit 1
        }
    done
}

main() {
    DRY_RUN=false
    for arg in "$@"; do
        [[ "$arg" == "--dry-run" ]] && DRY_RUN=true
    done

    check_dependencies
    log "INFO" "Running rc-expand.sh."
    #!/usr/bin/env bash
# rc-expand.sh — Seed .md files from rotkeeper-bom.yaml
set -euo pipefail
IFS=$'\n\t'

FORCE=${1:---skip}
if [[ "$FORCE" == "--force" ]]; then
  FORCE=true
else
  FORCE=false
fi

BOM="road-to-bones/rotkeeper-bom.yaml"
HOME_DIR="home"

if [[ "$DRY_RUN" == true ]]; then
    log "INFO" "[DRY RUN] Would create directory $HOME_DIR"
else
    mkdir -p "$HOME_DIR"
fi

echo "🧬 Expanding from buildout: $BOM"

# Check for yq
if ! command -v yq >/dev/null; then
  echo "❌ ERROR: 'yq' is required but not installed."
  echo "💡 Install it using your package manager:"
  echo "   brew install yq       # macOS"
  echo "   sudo apt install yq   # Debian/Ubuntu"
  echo "   sudo dnf install yq   # Fedora"
  echo "   or visit: https://github.com/mikefarah/yq"
  exit 1
fi

# Sanity check for BOM path
if [[ ! -f "$BOM" ]]; then
  echo "❌ ERROR: Buildout file not found: $BOM"
  echo "🧬 Expected at path: $BOM"
  exit 1
fi

# Loop through each content item in the BOM
page_count=$(yq e '.content | length' "$BOM")

for i in $(seq 0 $((page_count - 1))); do
  FILENAME=$(yq e ".content[$i].filename" "$BOM")
  TITLE=$(yq e ".content[$i].title" "$BOM")
  TEMPLATE=$(yq e ".content[$i].template" "$BOM")
  SUBTITLE=$(yq e ".content[$i].subtitle" "$BOM")
  BODY=$(yq e ".content[$i].body" "$BOM")

  OUTFILE="$HOME_DIR/$FILENAME"

  if [[ -f "$OUTFILE" && "$FORCE" != true ]]; then
    echo "⚠️  Skipping $OUTFILE (already exists)"
    continue
  fi

  echo "📄 Generating: $OUTFILE"
  if [[ "$DRY_RUN" == true ]]; then
      log "INFO" "[DRY RUN] Would write to $OUTFILE"
  else
      {
        echo "---"
        echo "title: \"$TITLE\""
        echo "template: $TEMPLATE"
        [[ -n "$SUBTITLE" && "$SUBTITLE" != "null" ]] && echo "subtitle: \"$SUBTITLE\""
        echo "---"
        echo ""
        echo "$BODY"
      } > "$OUTFILE"
  fi
done

echo "✅ Expansion complete."

# === SCRIPTS ===
# === SELF REPLICATION ===
SELF_DEST="bones/scripts/rc-expand.sh"
if [[ "$SELF_DEST" == "$SELF_DEST" ]]; then
  if [[ "$DRY_RUN" == true ]]; then
      log "INFO" "[DRY RUN] Would create directory $(dirname "$SELF_DEST")"
      log "INFO" "[DRY RUN] Would copy rc-expand.sh to $SELF_DEST"
      log "INFO" "[DRY RUN] Would chmod +x $SELF_DEST"
  else
      echo "🔄 Copying rc-expand.sh to $SELF_DEST"
      mkdir -p "$(dirname "$SELF_DEST")"
      cp "$0" "$SELF_DEST"
      chmod +x "$SELF_DEST"
  fi
fi

SCRIPT_NAME=$(basename "$0")

script_count=$(yq e '.scripts | length' "$BOM")
for i in $(seq 0 $((script_count - 1))); do
  SCRIPT_PATH=$(yq e ".scripts[$i].path" "$BOM")
  # Skip stubbing the expand script itself
  if [[ "$(basename "$SCRIPT_PATH")" == "$SCRIPT_NAME" ]]; then
    continue
  fi
  HEADER=$(yq e ".scripts[$i].header" "$BOM")
  STUB=$(yq e ".scripts[$i].stub" "$BOM")
  if [[ "$STUB" != "true" ]]; then
    echo "⚠️  Skipping $SCRIPT_PATH (stub: false)"
    continue
  fi
  if [[ ! -f "$SCRIPT_PATH" ]]; then
    if [[ "$DRY_RUN" == true ]]; then
        log "INFO" "[DRY RUN] Would create directory $(dirname "$SCRIPT_PATH")"
        log "INFO" "[DRY RUN] Would create script: $SCRIPT_PATH"
        log "INFO" "[DRY RUN] Would chmod +x $SCRIPT_PATH"
    else
        echo "⚙️  Creating script: $SCRIPT_PATH"
        mkdir -p "$(dirname "$SCRIPT_PATH")"
        {
          echo "#!/usr/bin/env bash"
          [[ "$HEADER" != "null" ]] && echo "# $HEADER"
          echo "# TODO"
        } > "$SCRIPT_PATH"
        chmod +x "$SCRIPT_PATH"
    fi
  fi
done

# === CONFIG FILES ===
config_count=$(yq e '.config | length' "$BOM")
for i in $(seq 0 $((config_count - 1))); do
  CONFIG_PATH=$(yq e ".config[$i].path" "$BOM")
  if [[ ! -f "$CONFIG_PATH" ]]; then
    if [[ "$DRY_RUN" == true ]]; then
        log "INFO" "[DRY RUN] Would create directory $(dirname "$CONFIG_PATH")"
        log "INFO" "[DRY RUN] Would touch config file: $CONFIG_PATH and write headers"
    else
        echo "📄 Touching config file: $CONFIG_PATH"
        mkdir -p "$(dirname "$CONFIG_PATH")"
        echo "# 🔮 Generated by rc-expand.sh" > "$CONFIG_PATH"
        echo "# ☠️ Do not edit unless you are bone-certified." >> "$CONFIG_PATH"
    fi
  fi
done

# === TEMPLATES ===
template_count=$(yq e '.templates | length' "$BOM")
for i in $(seq 0 $((template_count - 1))); do
  TEMPLATE_PATH=$(yq e ".templates[$i].path" "$BOM")
  SKELETON=$(yq e ".templates[$i].skeleton" "$BOM")
  if [[ ! -f "$TEMPLATE_PATH" && "$SKELETON" == "true" ]]; then
    if [[ "$DRY_RUN" == true ]]; then
        log "INFO" "[DRY RUN] Would create directory $(dirname "$TEMPLATE_PATH")"
        log "INFO" "[DRY RUN] Would create template skeleton: $TEMPLATE_PATH"
    else
        echo "🧱 Creating template skeleton: $TEMPLATE_PATH"
        mkdir -p "$(dirname "$TEMPLATE_PATH")"
        {
          echo "<!-- 🔮 Skeleton generated by rc-expand.sh -->"
          echo "<!DOCTYPE html>"
          echo "<html><head><title>\$title\$</title></head><body>"
          echo "\$body\$"
          echo "</body></html>"
        } > "$TEMPLATE_PATH"
    fi
  fi
done

# === FOLDERS ===
folder_count=$(yq e '.folders | length' "$BOM")
for i in $(seq 0 $((folder_count - 1))); do
  DIR=$(yq e ".folders[$i].path" "$BOM")
  echo "📁 Ensuring folder exists: $DIR"
  if [[ "$DRY_RUN" == true ]]; then
      log "INFO" "[DRY RUN] Would create directory $DIR"
      log "INFO" "[DRY RUN] Would touch $DIR/.keep"
  else
      mkdir -p "$DIR"
      touch "$DIR/.keep"
  fi
done


echo "🧾 Expand complete. Home content lives in: $HOME_DIR/"

# === DUMP ENTIRE SCRIPT ENVIRONMENT ===
echo "💾 Dumping all scripts to bones/scripts/"
if [[ "$DRY_RUN" == true ]]; then
    log "INFO" "[DRY RUN] Would create directory bones/scripts"
else
    mkdir -p bones/scripts
fi
for script in *.sh; do
  if [[ "$DRY_RUN" == true ]]; then
      log "INFO" "[DRY RUN] Would copy $script to bones/scripts/"
      log "INFO" "[DRY RUN] Would chmod +x bones/scripts/$script"
  else
      echo "🔄 Copying $script to bones/scripts/"
      cp "$script" "bones/scripts/$script"
      chmod +x "bones/scripts/$script"
  fi
done

# === COPY ROTKEEPER BOM ===
echo "📦 Copying BOM for environment replication"
if [[ "$DRY_RUN" == true ]]; then
    log "INFO" "[DRY RUN] Would create directory bones/scripts/road-to-bones"
    log "INFO" "[DRY RUN] Would copy $BOM to bones/scripts/road-to-bones/rotkeeper-bom.yaml"
else
    mkdir -p bones/scripts/road-to-bones
    cp "$BOM" bones/scripts/road-to-bones/rotkeeper-bom.yaml
fi
    log "INFO" "rc-expand.sh completed successfully."
}

main "$@"
