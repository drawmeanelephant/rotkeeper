#!/usr/bin/env bash
# ░▒▓█ ROTKEEPER SCRIPT █▓▒░
# Script: rc-scan.sh
# Purpose: Audit files vs manifest, classify orphans, and write digest reports
# Version: 0.1.9.9
# Updated: 2025-05-27
# -----------------------------------------
set -euo pipefail
IFS=$'\n\t'

if [ -z "${BASH_VERSION:-}" ]; then
    echo "🚨 rc-scan.sh requires bash. Please run with: bash ./rc-scan.sh" >&2
    exit 1
fi

LOG_FILE="bones/logs/rc-scan-$(date +%Y-%m-%d_%H%M).log"

mkdir -p "$(dirname "$LOG_FILE")"

log() {
    local level="$1"; shift
    printf '%s [%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$level" "$*" | tee -a "$LOG_FILE"
}

cleanup() {
    log "INFO" "Cleaning up after rc-scan.sh."
    # Add cleanup commands here
}
trap cleanup EXIT INT TERM

check_dependencies() {
    local deps=(git rsync ssh pandoc date)
    for cmd in "${deps[@]}"; do
        command -v "$cmd" >/dev/null 2>&1 || {
            log "ERROR" "$cmd required but not installed."
            exit 1
        }
    done
}

main() {
    check_dependencies
    log "INFO" "Running rc-scan.sh."
# rc-scan.sh — Audit manifest and scan environment for file reports
#
# Workflow:
# 1. Discover Target Paths
#    - Read bones/manifest.txt (if exists)
#    - Scan directories: home/, bones/, output/
#    Flags: --manifest-only (skip disk scan)
#
# 2. Filter & Classify
#    - Default types: png, jpg, svg, css, js, md, html, json, yaml
#    Flags: --include, --exclude
#
# 3. Compute File Metadata
#    - Path, size (bytes), mtime, checksum (SHA256)
#
# 4. Compare Against Manifest
#    - Identify missing files and orphans
#
# 5. Generate Reports
#    - JSON: bones/reports/scan-report.json
#    - Markdown: home/content/rotkeeper/scan-report.md
#    - Log: bones/logs/rc-scan.log
#
# 6. Expose Digests
#    - YAML: bones/reports/file-digests.yaml (path → checksum)
#
# 7. CLI Flags & Modes
#    - --dry-run, --verbose, --json-only, --md-only
#
# 8. Exit Codes
#    - 0: no issues
#    - >0: missing files or usage errors
#

#
# --- Configuration ---
# Set up default file paths, directories, and file type filters.
# Default configurations
MANIFEST_FILE="bones/manifest.txt"
SCAN_DIRS=("home/" "bones/" "output/")
REPORT_DIR="bones/reports"
LOG_DIR="bones/logs"
INCLUDE_EXT=("png" "jpg" "svg" "css" "js" "md" "html" "json" "yaml")
EXCLUDE_PATTERNS=()

#
# --- CLI Defaults & Argument Parsing ---
# Initialize CLI-related variables and parse command-line flags.
# CLI defaults
DRY_RUN=false
VERBOSE=false
JSON_ONLY=false
MD_ONLY=false

#
# Display usage help when requested or on error.
#
function usage {
  cat <<EOF
Usage: rc-scan.sh [flags]
Flags:
  --manifest-only   Read only manifest file, skip disk scan.
  --include <ext>   Comma-separated list of extensions to include.
  --exclude <pat>   Glob pattern to exclude (can repeat).
  --dry-run         Show actions without writing reports.
  --verbose         Print detailed logs.
  --json-only       Output only JSON report.
  --md-only         Output only Markdown report.
  -h, --help        Show this help.
EOF
  exit 1
}

#
# Parse input flags and options.
#
while [[ $# -gt 0 ]]; do
  case "$1" in
    --manifest-only) MANIFEST_ONLY=true; shift ;;
    --include) IFS=',' read -ra INCLUDE_EXT <<< "$2"; shift 2 ;;
    --exclude) EXCLUDE_PATTERNS+=("$2"); shift 2 ;;
    --dry-run) DRY_RUN=true; shift ;;
    --verbose) VERBOSE=true; shift ;;
    --json-only) JSON_ONLY=true; shift ;;
    --md-only) MD_ONLY=true; shift ;;
    -h|--help) usage ;;
    *) echo "[ERROR] Unknown flag: $1"; usage ;;
  esac
done

#
# Create necessary report and log directories.
#
mkdir -p "$REPORT_DIR" "$LOG_DIR"

LOG_FILE="$LOG_DIR/rc-scan-$(date +%Y%m%d_%H%M%S).log"
#
# Redirect all stdout/stderr to the log file.
#
exec > >(tee -a "$LOG_FILE") 2>&1

echo "[INFO] rc-scan started at $(date)"

#
# --- Step 1: Load Manifest ---
# Read manifest file entries into an associative array.
# Requires bash — associative array to track manifest files
declare -A manifest_map
if [[ -f "$MANIFEST_FILE" ]]; then
  while read -r line; do
    manifest_map["$line"]=1
  done < "$MANIFEST_FILE"
  echo "[INFO] Loaded manifest entries from $MANIFEST_FILE"
elif [[ "${MANIFEST_ONLY:-false}" == true ]]; then
  echo "[ERROR] Manifest file not found: $MANIFEST_FILE"; exit 2
fi

#
# --- Step 2: Disk Scan ---
# Walk specified directories, apply include/exclude filters.
# Requires bash — associative array to track discovered files
declare -A disk_map
if [[ "${MANIFEST_ONLY:-false}" != true ]]; then
  for dir in "${SCAN_DIRS[@]}"; do
    [[ -d "$dir" ]] || continue
    find "$dir" -type f | while read -r file; do
      ext="${file##*.}"
      # check include
      if [[ ! " ${INCLUDE_EXT[*]} " =~ " $ext " ]]; then
        $VERBOSE && echo "[SKIP] Extension filter: $file"
        continue
      fi
      # check exclude
      skip=false
      for pat in "${EXCLUDE_PATTERNS[@]}"; do
        [[ "$file" == $pat ]] && skip=true
      done
      $skip && { $VERBOSE && echo "[SKIP] Excluded by pattern: $file"; continue; }
      disk_map["$file"]=1
    done
  done
  echo "[INFO] Disk scan completed"
fi

#
# --- Step 3: Compare Manifest vs Disk ---
# Determine missing and orphaned files by comparing arrays.
# 3. Compare manifest vs disk
missing=(); orphans=()
for f in "${!manifest_map[@]}"; do
  if [[ ! -e "$f" ]]; then
    missing+=("$f")
  fi
done
for f in "${!disk_map[@]}"; do
  rel="${f#./}"
  if [[ -z "${manifest_map[$rel]}" ]]; then
    orphans+=("$rel")
  fi
done

#
# --- Step 4: Generate File Metadata ---
# Compute SHA256 checksums for each scanned file.
# Requires bash — file path to SHA256 digest
declare -A file_checksums
for f in "${!disk_map[@]}"; do
  sha=$(sha256sum "$f" | awk '{print $1}')
  file_checksums["$f"]="$sha"
done

#
# --- Step 5: JSON Report ---
# Output findings in JSON format.
# 5. Write JSON report
if [[ "$MD_ONLY" == false ]]; then
  json_report="$REPORT_DIR/scan-report-$(date +%Y%m%d_%H%M%S).json"
  {
    echo "{"
    echo "  \"missing\": [\"$(IFS='\",\"'; echo "${missing[*]}")\"],"
    echo "  \"orphans\": [\"$(IFS='\",\"'; echo "${orphans[*]}")\"],"
    echo "  \"digests\": {"
    for f in "${!file_checksums[@]}"; do
      echo "    \"${f}\": \"${file_checksums[$f]}\","
    done
    echo "  }"
    echo "}"
  } > "$json_report"
  echo "[INFO] JSON report written: $json_report"
fi

#
# --- Step 6: Markdown Report ---
# Output findings in Markdown format.
# 6. Write Markdown report
if [[ "$JSON_ONLY" == false ]]; then
  md_report="home/content/rotkeeper/scan-report-$(date +%Y%m%d_%H%M%S).md"
  {
    echo "# Scan Report - $(date)"
    echo "## Missing Files"
    for f in "${missing[@]}"; do echo "- $f"; done
    echo ""
    echo "## Orphan Files"
    for f in "${orphans[@]}"; do echo "- $f"; done
    echo ""
    echo "## File Digests"
    for f in "${!file_checksums[@]}"; do echo "- \`$f\`: ${file_checksums[$f]}"; done
  } > "$md_report"
  echo "[INFO] Markdown report written: $md_report"
fi

#
# --- Completion ---
# Final log entry and exit.
#
log "INFO" "rc-scan.sh completed successfully."
echo "[INFO] rc-scan completed at $(date)"
exit 0
}

main "$@"
