#!/usr/bin/env bash
# ░▒▓█ ROTKEEPER SCRIPT █▓▒░
# Script: rc-cleanup-bones.sh
# Purpose: Backup and prune unneeded directories and templates from bones/
# Version: 0.1.9.9
# Updated: 2025-05-27
# -----------------------------------------
set -euo pipefail
IFS=$'\n\t'

DRY_RUN=false


LOGDIR="bones/logs"
mkdir -p "$LOGDIR"
LOG_FILE="$LOGDIR/rc-cleanup-bones.log"

log() {
    local level="$1"; shift
    printf '%s [%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$level" "$*" | tee -a "$LOG_FILE"
}

cleanup() {
    log "INFO" "Cleaning up after rc-cleanup-bones.sh."
    # Add cleanup commands here
}
trap cleanup EXIT INT TERM

main() {
    if [[ "${1:-}" == "--dry-run" ]]; then
        DRY_RUN=true
        log "INFO" "Running in dry-run mode. No files will be deleted."
    fi

    log "INFO" "Starting bones cleanup routine."

    BONES_DIR="${1:-bones}"
    if [[ "$DRY_RUN" == true && "$BONES_DIR" == "--dry-run" ]]; then
        BONES_DIR="${2:-bones}"
    fi
    BACKUP_DIR="bones/backups"
    TIMESTAMP=$(date +%Y-%m-%d_%H%M)
    BACKUP_NAME="bones-backup-$TIMESTAMP.tar.gz"

    mkdir -p "$BACKUP_DIR"
    log "INFO" "Creating backup of $BONES_DIR at $BACKUP_DIR/$BACKUP_NAME"
    tar -czf "$BACKUP_DIR/$BACKUP_NAME" "$BONES_DIR"

    log "INFO" "Restoring bones to factory deploy state..."
    log "INFO" "Templates and scripts will not be deleted in this version of the cleanup."

    if [[ "$DRY_RUN" == false ]]; then
        rm -rf "$BONES_DIR/archive" "$BONES_DIR/graveyard" "$BONES_DIR/logs" "$BONES_DIR/user" "$BONES_DIR/rotkeeper_utils"
    else
        log "DRYRUN" "Would remove: $BONES_DIR/archive, $BONES_DIR/graveyard, $BONES_DIR/logs, $BONES_DIR/user, $BONES_DIR/rotkeeper_utils"
    fi

    log "INFO" "Bones directory restored to deploy-safe state."
}

main "$@"
