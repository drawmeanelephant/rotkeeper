#!/usr/bin/env bash
# ░▒▓█ ROTKEEPER SCRIPT █▓▒░
# Script: rc-pack.sh
# Purpose: Bundle the rendered output into a versioned .tar.gz archive and export markdown content to JSON.
# Version: 0.2.0
# Updated: 2025-05-27
# -----------------------------------------
set -euo pipefail
IFS=$'\n\t'

LOG_FILE="bones/logs/rc-pack-$(date +%Y-%m-%d_%H%M).log"
mkdir -p "$(dirname "$LOG_FILE")"

log() {
    local level="$1"; shift
    printf '%s [%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$level" "$*" | tee -a "$LOG_FILE"
}

cleanup() {
    log "INFO" "Cleaning up after rc-pack.sh."
    # Add cleanup commands here
}
trap cleanup EXIT INT TERM

# =============================================================================
# rc-pack.sh – Ritual Compression Packager
#
#   When rendering ends and the tombs are aligned,
#   This script collects what rot left behind.
#   With tarball and timestamp, it seals the decay,
#   And preps it for transit or end-of-day.
#
#   MODES:
#   - Default: archive only rendered output/
#   - --self:  full system bundle (rotkeeper.sh, bones/, home/, output/)
#   - --dry-run: preview without writing
#
#   FUTURE:
#   - Modular targeting, asset tagging, alt formats (Tiki, Sora, etc.)
#
# 💀 MANDATE:
# Preserve the rot. Export with intention. Archive before deletion.
# =============================================================================
main() {
    log "INFO" "Running rc-pack.sh."
    #!/usr/bin/env bash
# =============================================================================
# Script: rc-pack.sh
# Purpose: Bundle the rendered output into a versioned .tar.gz archive and export markdown content to JSON.
# =============================================================================

    # --- Shared Configuration ---
    CONFIG_DIR="bones"
    ARCHIVE_DIR="$CONFIG_DIR/archive"
    SOURCE_DIR="home/content"
    OUTPUT_DIR="output"
    MANIFEST_FILE="$CONFIG_DIR/manifest.txt"
    VERSION=$(date +%Y-%m-%d_%H%M)
    TOMB="tomb-$VERSION.tar.gz"
    EXPORT_JSON="$ARCHIVE_DIR/tomb-export-$VERSION.json"

    mkdir -p "$ARCHIVE_DIR"
    mkdir -p "$(dirname "$LOG_FILE")"

    DRY_RUN=false
    if [[ "${1:-}" == "--dry-run" ]]; then
      DRY_RUN=true
      log "INFO" "Running in dry-run mode. No files will be written."
    fi

    SELF_MODE=false
    if [[ "${1:-}" == "--self" ]]; then
      SELF_MODE=true
      log "INFO" "Running in self-pack mode. Entire system will be archived."
    fi

    # Ensure the rendered output directory exists before packing.
    if [ ! -d "$OUTPUT_DIR" ]; then
      echo "❌ No output directory to pack: $OUTPUT_DIR"
      exit 1
    fi

    if [[ "$SELF_MODE" == false ]]; then
      if [[ "$DRY_RUN" == false ]]; then
        echo "📦 Packing $OUTPUT_DIR into $TOMB"
        tar -czf "$ARCHIVE_DIR/$TOMB" "$OUTPUT_DIR"
        echo "🧾 Archived to $ARCHIVE_DIR/$TOMB"
        echo "$TOMB" >> "$MANIFEST_FILE"
      else
        log "DRYRUN" "Would pack $OUTPUT_DIR into $ARCHIVE_DIR/$TOMB"
      fi
    fi

    if [[ "$SELF_MODE" == true ]]; then
      SELF_ARCHIVE="tombkit-$VERSION.tar.gz"
      echo "📦 Packing full rotkeeper system into $SELF_ARCHIVE"
      tar -czf "$ARCHIVE_DIR/$SELF_ARCHIVE" \
        rotkeeper.sh bones/ home/ output/
      echo "🧾 Archived full tombkit to $ARCHIVE_DIR/$SELF_ARCHIVE"
      echo "$SELF_ARCHIVE" >> "$MANIFEST_FILE"
    fi

    if [[ "$SELF_MODE" == false ]]; then
      # --- Optional JSON Export ---
      # Export all Markdown files from the source content directory into a single JSON array.

      # Verify required tools (pandoc and jq) are installed for JSON export.
      if ! command -v pandoc >/dev/null || ! command -v jq >/dev/null; then
        echo "❌ Requires both pandoc and jq to export to JSON"
        exit 1
      fi

      if [[ "$DRY_RUN" == false ]]; then
        echo "🧬 Exporting .md from $SOURCE_DIR to JSON: $EXPORT_JSON"
        TMP_EXPORT=$(mktemp)
        echo "[" > "$TMP_EXPORT"
        FIRST=true
        find "$SOURCE_DIR" -name '*.md' | while read -r mdfile; do
          if ! CONTENT=$(pandoc "$mdfile" -t json 2>/dev/null); then
            log "ERROR" "Pandoc failed on $mdfile, skipping."
            continue
          fi

          JSON_ENTRY=$(jq -n --arg path "$mdfile" --argjson content "$CONTENT" \
            '{path: $path, pandoc_json: $content}')

          if [ "$FIRST" = true ]; then
            FIRST=false
          else
            echo "," >> "$TMP_EXPORT"
          fi
          echo "$JSON_ENTRY" >> "$TMP_EXPORT"
        done
        echo "]" >> "$TMP_EXPORT"
        mv "$TMP_EXPORT" "$EXPORT_JSON"
        echo "$EXPORT_JSON" >> "$MANIFEST_FILE"
        echo "✅ Export complete: $EXPORT_JSON"
      else
        log "DRYRUN" "Would export markdown from $SOURCE_DIR to JSON: $EXPORT_JSON"
      fi
    fi
    log "INFO" "rc-pack.sh completed successfully."
}

main "$@"
